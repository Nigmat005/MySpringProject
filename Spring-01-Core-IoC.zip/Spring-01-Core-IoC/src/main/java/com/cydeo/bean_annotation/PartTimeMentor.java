package com.cydeo.bean_annotation;

public class PartTimeMentor {
    public static void main(String[] args) {
        System.out.println("Part time mentor is created");
    }
}
