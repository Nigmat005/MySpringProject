package com.cydeo.bean_annotation;

public class FullTimeMentor {
    public static void createFulltimeMentor() {
        System.out.println("Full time mentor is created");
    }
}
